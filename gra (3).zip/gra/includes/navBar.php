<a href="http://www.genealogyresearchassistance.co.uk">
    <img id="logo" src="http://www.genealogyresearchassistance.co.uk/images/logo.jpg" alt="Two old images of people, left image has two people standing and one sitting, right image one female sat on a chair">
</a>

<nav id="primary_nav_wrap">
    <ul>
        <li><a href="http://www.genealogyresearchassistance.co.uk">Home</a></li>
        <li><a href="http://www.genealogyresearchassistance.co.uk/tips/">Tips</a>
            <ul>
                <li><a href="https://www.genealogyresearchassistance.co.uk/tips/#General">General Tips</a> </li>
                <li><a href="https://www.genealogyresearchassistance.co.uk/tips/#uk">UK Tips</a> </li>
                <li><a href="https://www.genealogyresearchassistance.co.uk/tips/#USA">USA Tips</a> </li>
            </ul>
        </li>
        <li><a href="#">Competitions</a>
            <ul>
                <li> <a href="http://www.genealogyresearchassistance.co.uk/competitions/view.php?comp_id=1">Christmas 2018</a></li>
                <li> <a href="http://www.genealogyresearchassistance.co.uk/competitions/termsAndConditions.php">Terms</a> </li>
            </ul>
        </li>
        <li><a href="http://www.genealogyresearchassistance.co.uk/usefulLinks">Library</a>
        <li><a href="http://www.genealogyresearchassistance.co.uk/about/Contact.php">Contact Us</a></li>
    </ul>
</nav>
<a href="https://www.facebook.com/GenealogyResearchAssistant/">
    <img id="fb" src="http://www.genealogyresearchassistance.co.uk/images/fblogo.jpg" alt="Facebook logo, white text on blue background, clicking will link to Genealogy Research Assistance facebook page">
</a>
