<li><a href="http://www.genealogyresearchassistance.co.uk/forum">Forum</a>
    <ul>
        <li><a href="http://www.genealogyresearchassistance.co.uk/forum/viewforum.php?f=16&sid=9a10ce5f8ab52cecdae0b3cacdaeecf8">Request assistance or lookups</a></li>
        <li><a href="http://www.genealogyresearchassistance.co.uk/forum/viewforum.php?f=17&sid=9a10ce5f8ab52cecdae0b3cacdaeecf8">Tips to help with research</a></li>
        <li><a href="http://www.genealogyresearchassistance.co.uk/forum/viewforum.php?f=19&sid=5a9c039102891c28ccf695800d0c7420">Chat</a></li>
        <li><a href="http://www.genealogyresearchassistance.co.uk/forum/viewforum.php?f=20&sid=5a9c039102891c28ccf695800d0c7420">Other good pages/Helpful links</a></li>
    </ul>
</li>
