-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 16, 2017 at 05:49 PM
-- Server version: 10.0.31-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `genealo1_Links`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `last added`
-- (See below for the actual view)
--
CREATE TABLE `last added` (
`ref` int(11)
,`Link` mediumtext
,`Typeinfo` int(11)
,`Location` int(11)
,`sitename` mediumtext
,`Disc` mediumtext
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lo and type`
-- (See below for the actual view)
--
CREATE TABLE `lo and type` (
`total` bigint(21)
,`lo_Name` varchar(100)
,`Typename` mediumtext
);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `Lo_ID` int(11) NOT NULL COMMENT 'Ref Location ',
  `lo_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`Lo_ID`, `lo_Name`) VALUES
(2, 'Australia'),
(3, 'Canada'),
(8, 'Channel Islands'),
(9, 'England'),
(14, 'Germany\r\n'),
(5, 'Ireland'),
(7, 'Isle of Man\r\n'),
(13, 'Malta'),
(6, 'New Zealand'),
(11, 'Norway'),
(12, 'Scotland\r\n'),
(15, 'South Africa\r\n'),
(1, 'UK\r\n'),
(4, 'USA'),
(10, 'Wales');

-- --------------------------------------------------------

--
-- Table structure for table `siteInfo`
--

CREATE TABLE `siteInfo` (
  `ref` int(11) NOT NULL COMMENT 'pk',
  `Link` mediumtext NOT NULL,
  `Typeinfo` int(11) NOT NULL COMMENT 'ref typeid',
  `Location` int(11) NOT NULL COMMENT 'ref locationid',
  `sitename` mediumtext NOT NULL,
  `Disc` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siteInfo`
--

INSERT INTO `siteInfo` (`ref`, `Link`, `Typeinfo`, `Location`, `sitename`, `Disc`) VALUES
(1, 'https://www.oldbaileyonline.org/', 1, 1, 'Old Bailey Online   ', 'Searchable proceedings of London\'s central criminal court 1674-1913.'),
(2, 'http://vcp.e2bn.org/', 1, 1, 'Victorian Crime and Punishment', 'Prisoner database with records and case study of Victorian Britain.'),
(3, 'http://www.genebug.net/crims.html', 1, 1, 'Criminal Register Index', 'Transcriptions of Gloucestershire Summary Convictions Register 1853-1879.'),
(4, 'http://www.capitalpunishmentuk.org/index18.html', 1, 1, 'Capital Punishment 18th & 19th Century', 'Case studies of crimes, in the 18th & 19th centuries.'),
(5, 'http://www.ontariogenealogy.com/cobourgcriminal.html', 1, 3, 'Cobourg Gaol Inmates 1832-1848', 'Ontario criminal database from 1832-1848'),
(6, 'http://members.pcug.org.au/~pdownes/dps/1stflt.htm', 1, 1, 'Australia\'s First Fleet', 'List of convicts sent from the UK to Australia on 13 May 1787'),
(7, 'http://members.pcug.org.au/~pdownes/dps/1stflt.htm', 1, 2, 'Australia\'s First Fleet', 'List of convicts sent from the UK to Australia on 13 May 1787'),
(8, 'http://www.slq.qld.gov.au/resources/family-history/convicts', 1, 2, 'State Library of Queensland', 'Convict transportation registers database 1787-1867'),
(9, 'http://www.slq.qld.gov.au/resources/family-history/convicts', 1, 1, 'State Library of Queensland', 'Convict transportation registers database 1787-1867'),
(10, 'http://www.theshipslist.com/', 5, 3, 'The Ships List', 'Immigration reports, newspaper records, shipwreck information, ship pictures, ship descriptions, \n    shipping-line fleet lists and more; as well as hundreds of passenger lists to Canada, USA, \n    Australia and even some for South Africa'),
(11, 'http://www.theshipslist.com/', 5, 2, 'The Ships List', 'Immigration reports, newspaper records, shipwreck information, ship pictures, ship descriptions, \n    shipping-line fleet lists and more; as well as hundreds of passenger lists to Canada, USA, \n    Australia and even some for South Africa'),
(12, 'http://www.theshipslist.com/', 5, 4, 'The Ships List', 'Immigration reports, newspaper records, shipwreck information, ship pictures, ship descriptions, \n    shipping-line fleet lists and more; as well as hundreds of passenger lists to Canada, USA, \n    Australia and even some for South Africa'),
(13, 'http://www.libertyellisfoundation.org/', 5, 4, 'Statue of Liberty - Ellis Island Foundation', 'Passenger Records of immigrants to the USA'),
(14, 'http://www.findboatpics.net/', 5, 6, 'Find Boat Pics', 'Picture Gallery of Passenger and Trade sailing ships to Australia and New Zealand between 1840 and 1890'),
(15, 'http://www.findboatpics.net/', 5, 2, 'Find Boat Pics', 'Picture Gallery of Passenger and Trade sailing ships to Australia and New Zealand between 1840 and 1890'),
(16, 'http://www.castlegarden.org/', 5, 4, 'Castle Garden', 'Database of information on 11 million immigrants from 1820 through 1892'),
(17, 'http://www.norwayheritage.com/query_s.asp', 5, 11, 'Norway Heritage', 'Database of Norweigan and other Transatlantic passenger lists'),
(18, 'http://www.naa.gov.au/collection/fact-sheets/fs124.aspx', 5, 1, 'National Archives of Australia - Child migration factsheet', 'Child migration into Australia'),
(19, 'http://www.naa.gov.au/collection/fact-sheets/fs124.aspx', 5, 2, 'National Archives of Australia - Child migration factsheet', 'Child migration into Australia'),
(20, 'http://www.naa.gov.au/collection/fact-sheets/fs124.aspx', 5, 13, 'National Archives of Australia - Child migration factsheet', 'Child migration into Australia'),
(21, 'http://1915crewlists.rmg.co.uk/', 5, 1, 'National Maritime Museum', 'Crew list of British Merchant Navy from 1915'),
(22, 'http://www.immigrantships.net/', 5, 1, 'Immigrants Ships', '17,000+ Passenger Manifests in 16 Volumes plus numerous other passengers listed in Special Projects.'),
(23, 'http://www.immigrantships.net/', 5, 2, 'Immigrants Ships', '17,000+ Passenger Manifests in 16 Volumes plus numerous other passengers listed in Special Projects.'),
(24, 'http://www.immigrantships.net/', 5, 3, 'Immigrants Ships', '17,000+ Passenger Manifests in 16 Volumes plus numerous other passengers listed in Special Projects.'),
(25, 'http://www.immigrantships.net/', 5, 4, 'Immigrants Ships', '17,000+ Passenger Manifests in 16 Volumes plus numerous other passengers listed in Special Projects.'),
(26, 'http://www.olivetreegenealogy.com/ships/irishtousa.shtml', 5, 1, 'Olive Tree Genealogy', 'Ships\' Passenger lists, Naturalization Records, Palatine Genealogy and much more'),
(27, 'http://www.olivetreegenealogy.com/ships/irishtousa.shtml', 5, 2, 'Olive Tree Genealogy', 'Ships\' Passenger lists, Naturalization Records, Palatine Genealogy and much more'),
(28, 'http://www.olivetreegenealogy.com/ships/irishtousa.shtml', 5, 3, 'Olive Tree Genealogy', 'Ships\' Passenger lists, Naturalization Records, Palatine Genealogy and much more'),
(29, 'http://www.olivetreegenealogy.com/ships/irishtousa.shtml', 5, 4, 'Olive Tree Genealogy', 'Ships\' Passenger lists, Naturalization Records, Palatine Genealogy and much more'),
(30, 'http://immigrants.byu.edu/main_page', 5, 1, 'Immigrant Ancestors Project', 'emigration registers to locate information about the birthplaces of immigrants in their native countries'),
(31, 'http://immigrants.byu.edu/main_page', 5, 2, 'Immigrant Ancestors Project', 'emigration registers to locate information about the birthplaces of immigrants in their native countries'),
(32, 'http://immigrants.byu.edu/main_page', 5, 3, 'Immigrant Ancestors Project', 'emigration registers to locate information about the birthplaces of immigrants in their native countries'),
(33, 'http://immigrants.byu.edu/main_page', 5, 4, 'Immigrant Ancestors Project', 'emigration registers to locate information about the birthplaces of immigrants in their native countries'),
(34, 'https://www.englandsimmigrants.com/', 5, 1, 'England Immigrants  1330-1550', 'A fully-searchable database of people known to have migrated to England during the period of the Hundred Years\' War and the Black Death, \n        the Wars of the Roses and the Reformation'),
(35, 'https://www.englandsimmigrants.com/', 5, 2, 'England Immigrants  1330-1550', 'A fully-searchable database of people known to have migrated to England during the period of the Hundred Years\' War and the Black Death, \n        the Wars of the Roses and the Reformation'),
(36, 'https://www.englandsimmigrants.com/', 5, 3, 'England Immigrants  1330-1550', 'A fully-searchable database of people known to have migrated to England during the period of the Hundred Years\' War and the Black Death, \n        the Wars of the Roses and the Reformation'),
(37, 'https://www.englandsimmigrants.com/', 5, 4, 'England Immigrants  1330-1550', 'A fully-searchable database of people known to have migrated to England during the period of the Hundred Years\' War and the Black Death, \n        the Wars of the Roses and the Reformation'),
(38, 'http://ryersonindex.net/search.php', 3, 2, 'The Ryerson Index', 'Death Notices and Obituaries from Australian Newspapers.'),
(39, 'http://canadianheadstones.com/on/cemeteries.php', 3, 3, 'Ontario, Canadian Headstones', 'Gravestone records for Ontario.'),
(40, 'http://www.interment.net/Default.htm', 3, 2, 'interment', 'Cemetery Records.'),
(41, 'http://www.interment.net/Default.htm', 3, 3, 'interment', 'Cemetery Records.'),
(42, 'http://www.interment.net/Default.htm', 3, 5, 'interment', 'Cemetery Records.'),
(43, 'http://www.interment.net/Default.htm', 3, 14, 'interment', 'Cemetery Records.'),
(44, 'http://www.interment.net/Default.htm', 3, 5, 'interment', 'Cemetery Records.'),
(45, 'http://www.interment.net/Default.htm', 3, 1, 'interment', 'Cemetery Records.'),
(46, 'http://www.interment.net/Default.htm', 3, 4, 'interment', 'Cemetery Records.'),
(47, 'http://www.cemeteries.org.uk/', 3, 9, 'Barnsley Cemeteries', 'Cemetery Records for Barnsley, Yorkshire.'),
(48, 'http://www.kentarchaeology.org.uk/Research/Libr/MIs/MIslist.html', 3, 9, 'kent archaeological society', 'Churchyard Monumental Inscriptions'),
(49, 'http://www.cityoflondon.gov.uk/burialRegisters/', 3, 9, 'City of London', 'Burial Registers'),
(50, 'http://crem.oltps.sthelens.gov.uk/', 3, 9, 'St Helens Council', 'Burial search of municipal cemetery'),
(51, 'http://www.tynesidesilentcities.com/index.html', 3, 9, 'Tyneside Silent Cities', 'Tyneside burial records'),
(52, 'https://blog.findmypast.co.uk/pre-1858-probate-jurisdictions-where-to-look-for-wills-1406192148.html', 3, 9, 'Find My Past', 'Blog on where to look for Wills'),
(53, 'http://www.nationalarchives.gov.uk/help-with-your-research/research-guides/wills-or-administrations-before-1858/', 3, 9, 'National Archives', 'Where to find Wills'),
(54, 'https://www.findagrave.com/', 3, 1, 'Find a Grave', 'Cemetery records'),
(55, 'https://www.findagrave.com/', 3, 2, 'Find a Grave', 'Cemetery records'),
(56, 'https://www.findagrave.com/', 3, 3, 'Find a Grave', 'Cemetery records'),
(57, 'https://www.findagrave.com/', 3, 4, 'Find a Grave', 'Cemetery records'),
(58, 'https://www.findagrave.com/', 3, 6, 'Find a Grave', 'Cemetery records'),
(59, 'http://www3.sympatico.ca/bkinnon/obit_links6.htm', 3, 1, 'Free Obituaries online', 'Obituary transcriptions'),
(60, 'http://www3.sympatico.ca/bkinnon/obit_links6.htm', 3, 2, 'Free Obituaries online', 'Obituary transcriptions'),
(61, 'http://www3.sympatico.ca/bkinnon/obit_links6.htm', 3, 3, 'Free Obituaries online', 'Obituary transcriptions'),
(62, 'http://www3.sympatico.ca/bkinnon/obit_links6.htm', 3, 4, 'Free Obituaries online', 'Obituary transcriptions'),
(63, 'http://www3.sympatico.ca/bkinnon/obit_links6.htm', 3, 6, 'Free Obituaries online', 'Obituary transcriptions'),
(64, 'https://www.deceasedonline.com/servlet/GSDOSearch', 3, 1, 'Deceased online (Subscription)', 'Burial Records'),
(65, 'https://www.deceasedonline.com/servlet/GSDOSearch', 3, 2, 'Deceased online (Subscription)', 'Burial Records'),
(66, 'https://www.deceasedonline.com/servlet/GSDOSearch', 3, 3, 'Deceased online (Subscription)', 'Burial Records'),
(67, 'https://www.deceasedonline.com/servlet/GSDOSearch', 3, 4, 'Deceased online (Subscription)', 'Burial Records'),
(68, 'https://www.deceasedonline.com/servlet/GSDOSearch', 3, 6, 'Deceased online (Subscription)', 'Burial Records'),
(69, 'https://billiongraves.com/', 3, 1, 'Billion Graves', 'Burial Records'),
(70, 'https://billiongraves.com/', 3, 2, 'Billion Graves', 'Burial Records'),
(71, 'https://billiongraves.com/', 3, 3, 'Billion Graves', 'Burial Records'),
(72, 'https://billiongraves.com/', 3, 4, 'Billion Graves', 'Burial Records'),
(73, 'https://billiongraves.com/', 3, 6, 'Billion Graves', 'Burial Records'),
(74, 'https://www.iannounce.co.uk/', 3, 1, 'iAnnounce', 'Obituary transcriptions'),
(75, 'https://mortiquarian.com/', 3, 1, 'Brighton Mortiquarian', 'Burial Ground'),
(76, 'http://www.gov.mb.ca/chc/archives/probate/index.html', 3, 3, 'Archives of Manitoba', 'Wills search'),
(77, 'https://probatesearch.service.gov.uk/#wills', 3, 9, 'Wills, Probate and Inheritance', 'Find a Will'),
(78, 'https://familysearch.org/search/collection/1865481', 3, 6, 'Family Search', 'Probate search for New Zealand'),
(79, 'https://familysearch.org/wiki/en/United_States_Probate_Wills', 3, 4, 'family search wiki', 'How to find a USA Wills'),
(80, 'http://www.racetimeplace.com/diseasedefinitions.htm', 4, 1, 'Disease definitions', 'Definition of Archaic diseases.'),
(81, 'http://www.nationalarchives.gov.uk/hospitalrecords/', 4, 1, 'Hospital Records Database', 'Hospital Records held at the National Archives'),
(82, 'http://www.redcross.org.uk/About-us/Who-we-are/Museum-and-archives/Resources-for-researchers/Volunteers-and-personnel-records', 4, 1, 'Red Cross', 'Red Cross records of volunteers and personnel'),
(83, 'http://www.lhaasdav.com/learningcenter/diseasesold.html', 4, 1, 'List of Old Diseases', 'List of diseases found on old death certificates'),
(84, 'http://www.archaicmedicalterms.com/', 4, 1, 'A Glossary of Archaic Medical Terms', 'Resource for Interpreting Causes of Death.'),
(85, 'http://www.lambethpalacelibrary.org/files/Medical_Licences.pdf', 4, 1, 'Lambeth Palace Medical Licences', 'Medical Licences Issued by the Archbishop of Canterbury 1535-1775'),
(86, 'http://www.jarrelook.co.uk/Urbex/Whittingham%20Asylum/Whittingham.htm', 4, 1, 'Whittingham Mental Asylum, Goosenargh, Lancashire', 'Whittingham Mental Asylum including some gravestones'),
(87, 'http://www.medicalpioneers.com/', 4, 2, 'Australia Medical Pioneers', 'A database of colonial doctors to 1875'),
(88, 'http://www.budwin.net/medicology/titlepage.html', 4, 1, 'Medicology', 'Home encyclopedia of Health'),
(89, 'http://www.scottish-ancestors.com/scottish-terms-diseases.html', 4, 12, 'Glossary of old Scottish Medical Terms', 'Glossary of old Scottish terms for cause of death'),
(90, 'http://kdfhs.org.uk/index.php?option=com_content&view=article&id=1&Itemid=30', 4, 2, 'Epidemics timeline', 'Major epidemic and disease timeline based on writing from 1700s and 1800s'),
(91, 'http://www.austlii.edu.au/au/other/sa_gazette/', 6, 2, 'South Australia Government Gazettes', 'Historical Government Gazettes'),
(92, 'http://www.britishcolonist.ca/colonist.htm', 6, 3, 'The British Colonist', 'The British Colonist Newspaper Archives'),
(93, 'https://www.irishnewsarchive.com/', 6, 5, 'Irish Newspaper Archive', 'Historical Irish Newspapers'),
(94, 'https://paperspast.natlib.govt.nz/', 6, 6, 'Past Papers', 'Historical Newspaper Archives'),
(95, 'http://www.historicalpapers.wits.ac.za/index.php?digitalItems%2FU%2F', 6, 15, 'Historical Newspaper Archives of Johannesburg', 'Historical newspaper Archives'),
(96, 'http://www.old-merseytimes.co.uk/index.html', 6, 9, 'Mersey Times', 'Transcriptions of Liverpool newspapers'),
(97, 'https://www.thegazette.co.uk/', 6, 9, 'The Gazette', 'London Gazette'),
(98, 'http://newspapers.library.wales/', 6, 10, 'Newspaper Library of Wales', 'Welsh Newspaper Archive'),
(99, 'http://www.britishnewspaperarchive.co.uk/', 6, 1, 'The British Newspaper Archive', 'Subscription site to UK Newspapers Archives'),
(100, 'http://nyshistoricnewspapers.org/', 6, 4, 'New York State Historical Newspapers', 'Historical Newspaper Archives'),
(101, 'https://bklyn.newspapers.com/', 6, 4, 'Brookland News Stand', 'Historical Newspaper Archives'),
(102, 'http://www.foxearth.org.uk/newspapers.html', 6, 9, 'The Newspaper Archive', 'Historical Newspaper Archives'),
(103, 'http://www.fultonhistory.com/Fulton.html', 6, 4, 'Fulton History', 'Historical Newspaper Archives'),
(104, 'http://ink.ourdigitalworld.org/searchadv', 6, 4, 'Online Digital World', 'Historical Newspaper Archives'),
(105, 'http://news.ourontario.ca/search', 6, 3, 'Ontario Newspaper Archive', 'Historical Newspaper Archives.'),
(106, 'http://news.milton.halinet.on.ca/2817388/data?grd=1208', 6, 3, 'Milton Public Library Newspapers', 'Historical Newspaper Archives'),
(107, 'http://trove.nla.gov.au/', 6, 2, 'Trove', 'Historical Newspaper Archives'),
(108, 'http://specialcollections.le.ac.uk/cdm/landingpage/collection/p16445coll4', 6, 1, 'University of Leicester Special Collections Online', 'Historical Directories'),
(109, 'http://www.theancestorhunt.com/blog/12564-free-us-historical-newspaper-links-big-june-2015-update#.WT15bGjytPZ', 6, 4, 'The Ancestor Hunt', 'Historical Newspaper Archives'),
(110, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 1, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(111, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 2, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(112, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 3, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(113, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 4, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(114, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 5, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(115, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 6, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(116, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 7, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(117, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 8, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(118, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 9, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(119, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 10, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(120, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 11, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(121, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 12, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(122, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 13, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(123, 'https://en.wikipedia.org/wiki/Wikipedia:List_of_online_newspaper_archives', 6, 14, 'Wikipedia List of online Newpaper Archives', 'List of online newspapers'),
(124, 'https://news.google.com/newspapers', 6, 1, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(125, 'https://news.google.com/newspapers', 6, 2, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(126, 'https://news.google.com/newspapers', 6, 3, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(127, 'https://news.google.com/newspapers', 6, 4, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(128, 'https://news.google.com/newspapers', 6, 5, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(129, 'https://news.google.com/newspapers', 6, 6, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(130, 'https://news.google.com/newspapers', 6, 7, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(131, 'https://news.google.com/newspapers', 6, 8, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(132, 'https://news.google.com/newspapers', 6, 9, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(133, 'https://news.google.com/newspapers', 6, 10, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(134, 'https://news.google.com/newspapers', 6, 11, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(135, 'https://news.google.com/newspapers', 6, 12, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(136, 'https://news.google.com/newspapers', 6, 13, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(137, 'https://news.google.com/newspapers', 6, 14, 'Google Newspaper Archive', 'Historical Newspaper Archives'),
(138, 'https://www.records.nsw.gov.au/archives/collections-and-research', 8, 2, 'New South Wales State Archives', 'Depository for State Archives'),
(139, 'http://www.hotkey.net.au/', 6, 2, 'New South Wales 1834 Old News index', 'Births,Deaths,Marriages & Inquests, mentioned in Sydney newspapers for the year 1834.'),
(140, 'http://www.historicalsocietynt.org.au/index.htm', 9, 2, 'History Society of Northern Territories', 'Northern Territories History'),
(141, 'http://www.catalog.slsa.sa.gov.au/screens/mainmenu.html', 8, 2, 'State Library of South Australia', 'Archival records and photographs.'),
(142, 'http://www.naa.gov.au/', 8, 2, 'Nation Archives of Australia', 'National Archives.'),
(143, 'https://www.linc.tas.gov.au/family-history/Pages/Birth-Death-Marriage.aspx', 3, 2, 'Tasmanian Government', 'Tasmanian Birth Marriages and Deaths.'),
(144, 'https://www.linc.tas.gov.au/family-history/Pages/Birth-Death-Marriage.aspx', 8, 2, 'Tasmanian Government', 'Tasmanian Birth Marriages and Deaths.'),
(145, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 1, 2, 'Public Records of Victoria', 'Family History Records.'),
(146, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 3, 2, 'Public Records of Victoria', 'Family History Records.'),
(147, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 4, 2, 'Public Records of Victoria', 'Family History Records.'),
(148, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 5, 2, 'Public Records of Victoria', 'Family History Records.'),
(149, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 7, 2, 'Public Records of Victoria', 'Family History Records.'),
(150, 'https://www.prov.vic.gov.au/explore-collection/explore-topic/family-history', 8, 2, 'Public Records of Victoria', 'Family History Records.'),
(151, 'http://www.slq.qld.gov.au/resources/family-history', 8, 2, 'State Library of Queensland', 'Family History Records.'),
(152, 'http://www.slq.qld.gov.au/resources/family-history', 3, 2, 'State Library of Queensland', 'Family History Records.'),
(153, 'https://www.nla.gov.au/research-guides/family-history', 9, 2, 'National Libray of Australia', 'Family History Records'),
(154, 'https://www.genealogysa.org.au/', 9, 2, 'Genealogy South Australia', 'South Australia Famliy History Information.'),
(155, 'https://www.sag.org.au/', 9, 2, 'Society of Asutralian Genealogists', 'Society of Asutralian Genealogists'),
(156, 'http://www.bdm.dotag.wa.gov.au/F/family_history.aspx?uid=8948-7352-6630-2234', 8, 2, 'Department of Justice', 'Goverment of Westen Australia Birth, Deaths, Marriages'),
(157, 'http://www.collectionscanada.gc.ca/', 1, 3, 'Goverment of Canada', 'Library and Archives'),
(158, 'http://www.collectionscanada.gc.ca/', 3, 3, 'Goverment of Canada', 'Library and Archives'),
(159, 'http://www.collectionscanada.gc.ca/', 5, 3, 'Goverment of Canada', 'Library and Archives'),
(160, 'http://www.collectionscanada.gc.ca/', 6, 3, 'Goverment of Canada', 'Library and Archives'),
(161, 'http://www.collectionscanada.gc.ca/', 8, 3, 'Goverment of Canada', 'Library and Archives'),
(162, 'http://www.canadiangenealogy.net/alberta/index.htm', 8, 3, 'Canada Genealogy', 'Alberta Canada History & Genealogy '),
(163, 'http://www.britishhomechildren.com/', 5, 3, 'British Home Children', 'Library and Archives'),
(164, 'http://www.canadiangenealogy.net', 9, 3, 'Canada Genealogy', 'Canada Genealogy Resources'),
(165, 'http://www.ontariogenealogy.com/', 9, 3, 'Ontario & Upper Canada', 'Genealogy & History'),
(166, 'http://www.ontariogenealogy.com/', 8, 3, 'Ontario & Upper Canada', 'Genealogy & History'),
(167, 'http://cemetery.canadagenweb.org/', 3, 3, 'Cemetery Project', 'Free Canadian Cemetery Directory Genealogists Since 2004'),
(168, 'https://bifhsgo.ca/cstm_upsAndDowns.php?page=27&nr=75&scl=fnd', 9, 3, 'British Isles Family of History Society of Greater Ottawa', 'Barnardos Up and Downs Magazines'),
(169, 'https://www.childmigrantstrust.com/our-work/child-migration-history', 5, 3, 'Child Migrants Trust', 'Child Migrants History'),
(170, 'http://peel.library.ualberta.ca/newspapers/', 6, 3, 'Peel\'s Prairie Provinces', 'University of Alberta Newspappers'),
(171, 'http://archives.gnb.ca/Search/VISSE/141B7.aspx?culture=en-CA&guid=F2F123BD-B877-457F-8863-535C082321EA', 7, 3, 'Provincis Archives of New Brunswick', 'Goverment Records (RS141) Births, Marriages, Deaths (B,M,D\'S)'),
(172, 'http://www.islandlife.org/genealogy_ald.htm', 9, 8, 'Alderney Genealogy', 'Island life'),
(173, 'http://forebears.co.uk/channel-islands/alderney/st-anne', 8, 8, 'st Anne Genalogical Records', 'St Anne\'s all types'),
(174, 'http://catalogue.jerseyheritage.org/categories/german-occupation-registration-cards/', 8, 8, 'Archives & Collections', 'Archives & Collections'),
(175, 'http://www.cumbria.gov.uk/archives/familyhistory/', 8, 1, 'Cumbria County Council ', 'Archive Service'),
(176, 'http://www.manchester-family-history-research.co.uk/index.html', 9, 1, 'Manchester Family', 'History Reasearch'),
(177, 'http://www.manchester-family-history-research.co.uk/index.html', 9, 9, 'Manchester Family', 'History Reasearch'),
(178, 'http://www.cumbria.gov.uk/archives/familyhistory/', 8, 9, 'Cumbria County Council ', 'Archive Service'),
(179, 'https://manchesterarchiveplus.wordpress.com/', 9, 1, 'Manchester Council Library', 'Archive + '),
(180, 'https://manchesterarchiveplus.wordpress.com/', 9, 9, 'Manchester Council Library', 'Archive + '),
(181, 'http://www.lan-opc.org.uk/', 8, 9, 'Lancashire Parish', 'Lancashire records'),
(182, 'http://crem.oltps.sthelens.gov.uk/', 8, 8, 'St Helens Council', 'St Helens Records'),
(183, 'http://crem.oltps.sthelens.gov.uk/', 8, 9, 'St Helens Council', 'St Helens Records'),
(184, 'https://www.wigan.gov.uk/Resident/Museums-archives/Wigan-Archives/Collections/Family-history.aspx', 8, 9, 'Wigan Council', 'Family History'),
(185, 'http://www.discover-liverpool.com/', 9, 9, 'Discover Liverpool & city Regions', 'Liverpool & City Regons with Ken Pye'),
(186, 'http://www.berkshirebmd.org.uk/', 8, 9, 'Berkshire County', 'B.M.D.\'S'),
(187, 'http://www.berkshirebmd.org.uk/', 3, 9, 'Berkshire County', 'B.M.D.\'S'),
(188, 'http://www.berkshireenclosure.org.uk/', 8, 9, 'Berkshire New Landscape', 'Records Office, Maps, Documents, & Manuscripts'),
(189, 'http://www.berkshireenclosure.org.uk/', 9, 9, 'Berkshire New Landscape', 'Records Office, Maps, Documents, & Manuscripts'),
(190, 'http://www.knightroots.co.uk/parishes.htm', 8, 9, 'Hampshire (O.P.C) Oline Parish Clarks', 'Transcription Archive'),
(191, 'http://yateleylocalhistory.pbworks.com/w/page/9286141/YateleyParishRecords', 8, 1, 'Yateley Local History', 'Yateley Parish Records'),
(192, 'http://www.isle-of-wight-fhs.co.uk/bmd/startbmd.html', 8, 8, 'Isle Of Wight', 'Family History B.M.D.\'S'),
(193, 'http://www.isle-of-wight-fhs.co.uk/bmd/startbmd.html', 8, 8, 'Isle Of Wight', 'Family History B.M.D.\'S'),
(194, 'http://rshg.org.uk/', 9, 8, 'Ryde R.S.H.G', 'Social Heritage Group'),
(195, 'http://cityark.medway.gov.uk/query/results/?Mode=Search&PathList=%2FZ4a_Medway_Ancestors%2F&SearchWords&DateList', 9, 1, 'Medway Cityark', 'Public Records'),
(196, 'https://wills.canterbury-cathedral.org/', 3, 1, 'Canterbury', 'Probate Records 1396-1858 '),
(197, 'https://wills.canterbury-cathedral.org/', 3, 9, 'Canterbury', 'Probate Records 1396-1858 '),
(198, 'http://www.kentarchaeology.org.uk/Research/Libr/MIs/MIslist.htm', 3, 1, 'Kent Archaeological Society', 'C.M.I.\'S Churchyards Monumental Inscriptions '),
(199, 'http://www.kentarchaeology.org.uk/Research/Libr/MIs/MIslist.htm', 3, 9, 'Kent Archaeological Society', 'C.M.I.\'S Churchyards Monumental Inscriptions '),
(200, 'http://wills.oxfordshirefhs.org.uk/index.html', 3, 1, 'Oxfordshire Family History Society', 'Transcribed Wills'),
(201, 'http://wills.oxfordshirefhs.org.uk/index.html', 3, 9, 'Oxfordshire Family History Society', 'Transcribed Wills'),
(202, 'http://whipple.org/oxford/diocesan_marriage_bonds.html', 8, 1, 'Oxford Diocese Marriage Bonds', 'Diocese Marriage Bonds & Affidavits, 1661-1850 '),
(203, 'http://whipple.org/oxford/diocesan_marriage_bonds.html', 8, 9, 'Oxford Diocese Marriage Bonds', 'Diocese Marriage Bonds & Affidavits, 1661-1850 '),
(204, 'http://www.sussex-opc.org/', 8, 1, 'Sussex (O.P.C)  Oline Parish Clarks', 'East & West Sussex'),
(205, 'http://www.sussex-opc.org/', 8, 9, 'Sussex (O.P.C)  Oline Parish Clarks', 'East & West Sussex'),
(206, 'http://www.runaways.gla.ac.uk/', 9, 1, 'Runaways in Britain', 'Runaway Slaves in Britain'),
(207, 'http://www.runaways.gla.ac.uk/', 9, 9, 'Runaways in Britain', 'Runaway Slaves in Britain'),
(208, 'http://www.sussexrecordsociety.org/', 8, 1, 'Sussex Society', 'Records 1066-WW1'),
(209, 'http://www.sussexrecordsociety.org/', 8, 9, 'Sussex Society', 'Records 1066-WW1'),
(210, 'http://theweald.org/', 8, 1, 'Genealogy & Topography History Prior WW2', 'Records of Weald, Kent, Surrey & Sussex '),
(211, 'http://theweald.org/', 8, 9, 'Genealogy & Topography History Prior WW2', 'Records of Weald, Kent, Surrey & Sussex '),
(212, 'http://wsfhs.co.uk/pages/index.php', 9, 1, 'West Surrey FHS', 'Family History Society'),
(213, 'http://wsfhs.co.uk/pages/index.php', 9, 9, 'West Surrey FHS', 'Family History Society'),
(214, 'http://wsfhs.co.uk/pages/index.php', 8, 1, 'West Surrey FHS', 'Family History Society'),
(215, 'http://wsfhs.co.uk/pages/index.php', 8, 9, 'West Surrey FHS', 'Family History Society'),
(216, 'http://www.militaryarchives.ie/collections/online-collections/military-service-pensions-collection', 7, 5, 'Military Archives', 'Military Service Pensions Collections'),
(217, 'http://soldierswills.nationalarchives.ie/search/sw/index.jsp', 3, 5, 'National Archves Ireland (Soldiers wills)', 'Soldiers Wills'),
(218, 'http://www.opc-cornwall.org/', 8, 1, 'Cornwall (O.P.C)  Oline Parish Clarks', 'Family History'),
(219, 'http://www.opc-cornwall.org/', 8, 9, 'Cornwall (O.P.C)  Oline Parish Clarks', 'Family History'),
(220, 'http://west-penwith.org.uk/index.htm', 9, 1, 'West Penwith', 'Resources'),
(221, 'http://west-penwith.org.uk/index.htm', 9, 9, 'West Penwith', 'Resources'),
(222, 'http://www.devonheritage.org/FrameMain_ParishRecords.htm', 8, 1, 'Devon Heritage', 'Parish Records'),
(223, 'http://www.devonheritage.org/FrameMain_ParishRecords.htm', 8, 9, 'Devon Heritage', 'Parish Records'),
(224, 'http://www.opcdorset.org/', 8, 1, 'Dorset (O.P.C)  Oline Parish Clarks', 'Parish Clarks Records'),
(225, 'http://www.opcdorset.org/', 8, 9, 'Dorset (O.P.C)  Oline Parish Clarks', 'Parish Clarks Records'),
(226, 'http://www.weymouth-dorset.co.uk/family-history.html', 8, 1, 'Waymouth-Dorset', 'Family History & Genealogy'),
(227, 'http://www.weymouth-dorset.co.uk/family-history.html', 8, 9, 'Waymouth-Dorset', 'Family History & Genealogy'),
(228, 'http://www.genealogylinks.net/uk/england/dorset/', 8, 1, 'Dorset Genealogy', 'Records Births (150 Links)'),
(229, 'http://www.genealogylinks.net/uk/england/dorset/', 8, 9, 'Dorset Genealogy', 'Records Births (150 Links)'),
(230, 'http://www.gloucestershire.gov.uk/archives/index/?articleid=107388', 8, 1, 'Gloucestershire', 'County Council'),
(231, 'http://www.gloucestershire.gov.uk/archives/index/?articleid=107388', 8, 9, 'Gloucestershire', 'County Council'),
(232, 'http://gfhs.org.uk/', 8, 1, 'Gloucestershire FHS', 'Family History Society'),
(233, 'http://gfhs.org.uk/', 8, 9, 'Gloucestershire FHS', 'Family History Society'),
(234, 'http://www.wsom.org.uk/Parreg.html', 8, 1, 'West Somerset', 'Parish Reg: Transcriptions'),
(235, 'http://www.wsom.org.uk/Parreg.html', 8, 9, 'West Somerset', 'Parish Reg: Transcriptions'),
(236, 'https://history.wiltshire.gov.uk/heritage/', 8, 1, 'Wiltshire Council', 'Wiltshire & Swindon Archives'),
(237, 'https://history.wiltshire.gov.uk/heritage/', 8, 9, 'Wiltshire Council', 'Wiltshire & Swindon Archives'),
(238, 'http://www.wiltshire-opc.org.uk/', 8, 1, 'Wiltshire (O.P.C)  Oline Parish Clarks ', 'Parish Records'),
(239, 'http://www.wiltshire-opc.org.uk/', 8, 9, 'Wiltshire (O.P.C)  Oline Parish Clarks ', 'Parish Records'),
(240, 'http://www.cemeteries.org.uk/', 3, 1, 'Barnsley Dearne Memorial Groups D.M.G.', 'Barnsley Cemeteries Project DMG'),
(241, 'http://www.cemeteries.org.uk/', 3, 9, 'Barnsley Dearne Memorial Groups D.M.G.', 'Barnsley Cemeteries Project DMG'),
(242, 'http://www.picturesheffield.com/', 9, 1, 'Sheffield (pictures)', 'Pictures Archives'),
(243, 'http://www.picturesheffield.com/', 9, 9, 'Sheffield (pictures)', 'Pictures Archives'),
(244, 'http://www.yorkshireroots.org.uk/', 9, 1, 'Yorkshire Roots', 'Family History & Archaeological'),
(245, 'http://www.yorkshireroots.org.uk/', 9, 9, 'Yorkshire Roots', 'Family History & Archaeological'),
(246, 'http://www.roll-of-honour.com/Yorkshire/', 8, 1, 'Yorkshire ', 'Roll-of-Honour (Lest we Forget)'),
(247, 'http://www.roll-of-honour.com/Yorkshire/', 8, 9, 'Yorkshire ', 'Roll-of-Honour (Lest we Forget)'),
(248, 'http://www.sheffieldrecordsonline.org.uk/', 8, 1, 'Sheffield (records)', 'Records Online'),
(249, 'http://www.sheffieldrecordsonline.org.uk/', 8, 9, 'Sheffield (records)', 'Records Online'),
(250, 'http://www.leodis.net/', 9, 1, 'Leeds', 'Leodis Photos Archives'),
(251, 'http://www.leodis.net/', 9, 9, 'Leeds', 'Leodis Photos Archives'),
(252, 'http://yorkcastleprison.org.uk/home.html', 9, 1, 'York', 'Yorkcastle Prison Family History'),
(253, 'http://yorkcastleprison.org.uk/home.html', 9, 9, 'York', 'Yorkcastle Prison Family History'),
(254, 'http://www.wharfedalefhg.org/', 8, 1, 'Wharfedale FHG', 'Family History Groups FHG'),
(255, 'http://www.wharfedalefhg.org/', 8, 9, 'Wharfedale FHG', 'Family History Groups FHG'),
(256, 'http://discovery.nationalarchives.gov.uk/', 8, 1, 'UK Archives Britain', 'All British Archives'),
(257, 'http://discovery.nationalarchives.gov.uk/', 8, 9, 'UK Archives Britain', 'All British Archives'),
(258, 'http://discovery.nationalarchives.gov.uk/', 3, 1, 'UK Archives Britain', 'All British Archives'),
(259, 'http://discovery.nationalarchives.gov.uk/', 3, 9, 'UK Archives Britain', 'All British Archives'),
(260, 'http://discovery.nationalarchives.gov.uk/', 6, 1, 'UK Archives Britain', 'All British Archives'),
(261, 'http://discovery.nationalarchives.gov.uk/', 6, 9, 'UK Archives Britain', 'All British Archives'),
(262, 'http://freepages.genealogy.rootsweb.ancestry.com/~blanchec/EMidBaps.htm?hc_location=ufi', 9, 1, 'East Midlands', 'General Baptist History'),
(263, 'http://freepages.genealogy.rootsweb.ancestry.com/~blanchec/EMidBaps.htm?hc_location=ufi', 9, 9, 'East Midlands', 'General Baptist History'),
(264, 'http://www.askaboutireland.ie/', 9, 5, 'Ask About Ireland', 'Ask About Ireland'),
(265, 'https://www.johngrenham.com/places/', 9, 5, 'Irish Placenames', 'Irish Ancestory'),
(266, 'http://downsurvey.tcd.ie/landowners.php', 8, 5, 'Trinity College Dublin', 'Down Survey of Ireland'),
(267, 'http://titheapplotmentbooks.nationalarchives.ie/search/tab/home.jsp', 8, 5, 'National Archves Ireland', 'Applotment Book 1823-1837'),
(268, 'http://census.militaryarchives.ie/', 7, 5, 'Military Archives', 'Irish Army Census'),
(269, 'https://www.libertyellisfoundation.org/', 5, 5, 'Statue of Liberty Ellis Island', 'Ellis Island Passenger Search'),
(270, 'http://members.pcug.org.au/~ppmay/cgi-bin/irish/irish.cgi', 5, 5, 'Irish Convicts to Austraila Coleneys', 'Irish Convicts to New south Wales'),
(271, 'http://www.irishfaminememorial.org/en/orphans/', 5, 5, 'Famine Orphan Girls', 'Famine Memorial Sydney'),
(272, 'http://www.rootsireland.ie/', 8, 5, 'Find Irish Ancestors', 'Database of the Catholic Church'),
(273, 'http://www.from-ireland.net/', 8, 5, 'Free Irish Genealogy', 'Find Irish Birth Records, Certificates'),
(274, 'http://www.capitalpunishmentuk.org/ir1835.html', 9, 5, 'Irish ececutions', 'Irish ececutions from 1835-1899'),
(275, 'http://www.ireland-genealogy.com/', 8, 5, 'Ireland Genealogy', 'Irish Records'),
(276, 'http://www.genealogylinks.net/uk/ireland/sligo/', 9, 5, 'Ireland Genealogy (links)', 'County Sligo Genealogy'),
(277, 'http://www.leitrim-roscommon.com/index.shtml', 9, 5, 'Leitrim-Roscommon', 'Database of Resources'),
(278, 'http://www.glasnevintrust.ie/', 9, 5, 'Cematerys & Museums', 'Genealogy Dublin & Attractions'),
(279, 'http://www.coraweb.com.au/Search?q=Ireland', 9, 5, 'Cora web Search all Datebase', 'Databases'),
(280, 'https://www.italiangenealogy.com/', 9, 5, 'Italgen', 'Irish Italian'),
(281, 'http://www.rootsweb.ancestry.com/~irldub/', 9, 5, 'County Dublin', 'Irish Web Project'),
(282, 'http://www.clarelibrary.ie/eolas/coclare/genealogy/genealog.htm', 8, 5, 'Clare County Library', 'Family History'),
(283, 'http://www.corkarchives.ie/collections/onlinedigitalarchive/', 8, 5, 'Cork City', 'County Archives Collections'),
(284, 'http://mykerryancestors.com/services/free-genealogy-search/', 9, 5, 'Kerry Genealogy', 'Irish Roots');

--
-- Triggers `siteInfo`
--
DELIMITER $$
CREATE TRIGGER `ref` BEFORE INSERT ON `siteInfo` FOR EACH ROW SET NEW.ref = (SELECT MAX(ref) +  1 FROM siteInfo)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `totals_loctaion`
-- (See below for the actual view)
--
CREATE TABLE `totals_loctaion` (
`total` bigint(21)
,`Lo_Name` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `totals_type`
-- (See below for the actual view)
--
CREATE TABLE `totals_type` (
`total` bigint(21)
,`Typename` mediumtext
);

-- --------------------------------------------------------

--
-- Table structure for table `type_tab`
--

CREATE TABLE `type_tab` (
  `TypeID` int(11) NOT NULL COMMENT 'ref type',
  `Typename` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_tab`
--

INSERT INTO `type_tab` (`TypeID`, `Typename`) VALUES
(1, 'Criminal'),
(2, 'comps'),
(3, 'Gravestones Obituaries and Wills'),
(4, 'Medical Matters'),
(5, 'Migration'),
(6, 'Newspapers and Periodicals'),
(7, 'Occupations'),
(8, 'Parish Records'),
(9, 'History and refance');

-- --------------------------------------------------------

--
-- Structure for view `last added`
--
DROP TABLE IF EXISTS `last added`;

CREATE ALGORITHM=UNDEFINED DEFINER=`genealo1`@`localhost` SQL SECURITY DEFINER VIEW `last added`  AS  select `siteInfo`.`ref` AS `ref`,`siteInfo`.`Link` AS `Link`,`siteInfo`.`Typeinfo` AS `Typeinfo`,`siteInfo`.`Location` AS `Location`,`siteInfo`.`sitename` AS `sitename`,`siteInfo`.`Disc` AS `Disc` from `siteInfo` where (`siteInfo`.`ref` > ((select max(`siteInfo`.`ref`) from `siteInfo`) - 10)) ;

-- --------------------------------------------------------

--
-- Structure for view `lo and type`
--
DROP TABLE IF EXISTS `lo and type`;

CREATE ALGORITHM=UNDEFINED DEFINER=`genealo1`@`localhost` SQL SECURITY DEFINER VIEW `lo and type`  AS  select count(`siteInfo`.`ref`) AS `total`,`location`.`lo_Name` AS `lo_Name`,`type_tab`.`Typename` AS `Typename` from ((`location` join `siteInfo` on((`location`.`Lo_ID` = `siteInfo`.`Location`))) join `type_tab` on((`siteInfo`.`Typeinfo` = `type_tab`.`TypeID`))) group by `location`.`lo_Name`,`type_tab`.`Typename` ;

-- --------------------------------------------------------

--
-- Structure for view `totals_loctaion`
--
DROP TABLE IF EXISTS `totals_loctaion`;

CREATE ALGORITHM=UNDEFINED DEFINER=`genealo1`@`localhost` SQL SECURITY DEFINER VIEW `totals_loctaion`  AS  select count(`siteInfo`.`Location`) AS `total`,`location`.`lo_Name` AS `Lo_Name` from (`location` left join `siteInfo` on((`siteInfo`.`Location` = `location`.`Lo_ID`))) group by `location`.`lo_Name` ;

-- --------------------------------------------------------

--
-- Structure for view `totals_type`
--
DROP TABLE IF EXISTS `totals_type`;

CREATE ALGORITHM=UNDEFINED DEFINER=`genealo1`@`localhost` SQL SECURITY DEFINER VIEW `totals_type`  AS  select count(`siteInfo`.`Typeinfo`) AS `total`,`type_tab`.`Typename` AS `Typename` from (`type_tab` left join `siteInfo` on((`siteInfo`.`Typeinfo` = `type_tab`.`TypeID`))) group by `type_tab`.`Typename` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`Lo_ID`),
  ADD UNIQUE KEY `lo_Name` (`lo_Name`);

--
-- Indexes for table `siteInfo`
--
ALTER TABLE `siteInfo`
  ADD PRIMARY KEY (`ref`),
  ADD KEY `ref` (`ref`),
  ADD KEY `locatio_idx` (`Location`),
  ADD KEY `type_idx` (`Typeinfo`);

--
-- Indexes for table `type_tab`
--
ALTER TABLE `type_tab`
  ADD PRIMARY KEY (`TypeID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `siteInfo`
--
ALTER TABLE `siteInfo`
  ADD CONSTRAINT `type` FOREIGN KEY (`Typeinfo`) REFERENCES `type_tab` (`TypeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
