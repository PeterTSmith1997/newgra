INSERT INTO `siteInfo` (`ref`, `sitename`, `Link`,  `Disc`, `Typeinfo`, `Location`) VALUES
		();