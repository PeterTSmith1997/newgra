<!DOCTYPE html>
<html lang="en">
<head>
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
					(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-55673568-5', 'auto');
		ga('send', 'pageview');

	</script>
	<meta charset="UTF-8">
	<link href="../css/main.css" rel="stylesheet" type="text/css">
	<link rel="icon" href="../images/favicon.ico" type="image/x-icon"/>
	<meta name = "viewport" content="width=device-width, maximum-scale=1.0"/>
	<title>Contact - Genealogy Research Assistance</title>
</head>
<body>
<?php
include '../includes/navBar.php';
?>
<main>
	<h1>Contact us</h1>
		<p>Our admins can be contacted  on the form below</p>
		<form id="contact" method="post" enctype="multipart/form-data" action="../formmail/formmail.php">
			<input type="hidden" name="subject" value="Web_Contact">
			<input type="hidden" name="recipients" value="myaddress">
			<input type="hidden" name="good_url" value="http://www.genealogyresearchassistance.co.uk/about/thanks.php">
			<fieldset>
				<legend>
					<label>Contact us</label>
				</legend>
					<label for="firstname">First name</label>
					<input type="text" name="firstname"  id="firstname" required/>
					<label for="lastname">Last name</label>
					<input type="text" name="lastname"  id="lastname"/>
					<label for="email">Email address </label>
					<input  id="email" name="email" type="email" required>
					<label for="subject">Subject:</label>
					<input type="text" name="subject" id="subject" required minlength="10" maxlength="100">
					<label for="category">category</label>
					<select name="category" id="category">
						<option value="General inquiry">General inquiry</option>
						<option value="Look up request">Look up request</option>
						<option value="Suggestion/feedback">Suggestion/feedback</option>
						<option value="Site support">Site support</option>
						<option value="Other">Other</option>
					</select>
					<label for="message"> What is your message?</label>
					<textarea id="message" name="message" required minlength="50" maxlength="999"></textarea>
			</fieldset>
			<input type="submit" value="send it!">
		</form>

	<?php
	include '../includes/footer.php';
	echo poweredBy("https://www.petersweb.me.uk/invoicing/link.php?id=3")
	?>
</main>
</body>
</html>