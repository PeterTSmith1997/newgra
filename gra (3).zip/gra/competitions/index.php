<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include 'database_conn.php';      // make db connection
    ?>
    <meta charset="UTF-8">
    <link href="../css/main.css" rel="stylesheet" type="text/css">
    <meta name="viewpoint" content="width=device-width, maximum-scale=1.0">
    <title>Title</title>
</head>
<body>
<nav>
    <ul class="menu">
        <li class="dropdown">
            <a href="comps.html" class="dropbtn">Add a question</a>
        </li>
        <li class="dropdown">
            <a href="Tips.html" class="dropbtn">Tips</a>
            <div class="dropdown-content">
                <a href="Tips.html"> TIP 1</a>
            </div>

    </ul>
</nav>

<main>
    <h1 id="home"> Add a question</h1>

    <?php
    /**
     * Created by PhpStorm.
     * User: Student
     * Date: 19/03/2017
     * Time: 18:54
     */

    // form

    // select from comp cat

    // dropdown

    //end
    ?>
</main>
</body>
</html>
